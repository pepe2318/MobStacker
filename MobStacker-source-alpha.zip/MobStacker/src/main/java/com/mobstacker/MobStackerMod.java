package com.mobstacker;

import com.mobstacker.api.StackableMob;
import com.mobstacker.api.StackableSpawner;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class MobStackerMod implements ModInitializer {
    public static final String MOD_ID = "mobstacker";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final int MAX_MOB_STACK = 10_000;
    private static final double MERGE_RADIUS = 4.0;

    @Override
    public void onInitialize() {
        ServerTickEvents.END_WORLD_TICK.register(MobStackerMod::onWorldTick);
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient()) return ActionResult.PASS;
            ItemStack held = player.getStackInHand(hand);
            if (!held.isOf(Items.SPAWNER)) return ActionResult.PASS;

            BlockPos clicked = hit.getBlockPos();
            BlockPos destination = findSpawnerTarget(world, clicked, hit.getSide());
            if (destination == null) return ActionResult.PASS;
            BlockEntity blockEntity = world.getBlockEntity(destination);
            if (!(blockEntity instanceof StackableSpawner stacked)) return ActionResult.PASS;

            stacked.mobstacker$setStackSize(saturatingAdd(stacked.mobstacker$getStackSize(), 1L));
            blockEntity.markDirty();
            world.updateListeners(destination, world.getBlockState(destination), world.getBlockState(destination), 3);
            if (!player.getAbilities().creativeMode) held.decrement(1);
            player.sendMessage(Text.literal("Spawner stack: " + stacked.mobstacker$getStackSize()), true);
            return ActionResult.SUCCESS;
        });
        LOGGER.info("MobStacker alpha initialized (Minecraft 1.21.10 / Fabric).");
    }

    private static long saturatingAdd(long a, long b) {
        if (Long.MAX_VALUE - a < b) return Long.MAX_VALUE;
        return a + b;
    }

    private static BlockPos findSpawnerTarget(World world, BlockPos clicked, Direction side) {
        if (world.getBlockEntity(clicked) instanceof MobSpawnerBlockEntity) return clicked;
        BlockPos placedAt = clicked.offset(side);
        for (Direction direction : Direction.values()) {
            BlockPos candidate = placedAt.offset(direction);
            if (world.getBlockEntity(candidate) instanceof MobSpawnerBlockEntity) return candidate;
        }
        return null;
    }

    private static void onWorldTick(ServerWorld world) {
        if ((world.getTime() % 10L) != 0L) return;
        java.util.Set<MobEntity> nearbyMobs = new java.util.LinkedHashSet<>();
        for (var player : world.getPlayers()) {
            nearbyMobs.addAll(world.getEntitiesByClass(MobEntity.class,
                    player.getBoundingBox().expand(48.0), MobEntity::isAlive));
        }
        List<MobEntity> mobs = List.copyOf(nearbyMobs);

        for (MobEntity anchor : mobs) {
            if (!isEligible(anchor)) continue;
            StackableMob anchorStack = (StackableMob) anchor;
            if (anchorStack.mobstacker$getStackSize() >= MAX_MOB_STACK) continue;

            List<MobEntity> nearby = world.getEntitiesByClass(MobEntity.class,
                    anchor.getBoundingBox().expand(MERGE_RADIUS),
                    other -> other != anchor && other.isAlive() && other.getType() == anchor.getType());

            for (MobEntity other : nearby) {
                if (anchor.getId() >= other.getId() || !isEligible(other)) continue;
                if (anchor.squaredDistanceTo(other) > MERGE_RADIUS * MERGE_RADIUS) continue;

                StackableMob otherStack = (StackableMob) other;
                int room = MAX_MOB_STACK - anchorStack.mobstacker$getStackSize();
                if (room <= 0) break;
                int transfer = Math.min(room, otherStack.mobstacker$getStackSize());
                anchorStack.mobstacker$setStackSize(anchorStack.mobstacker$getStackSize() + transfer);
                int remainder = otherStack.mobstacker$getStackSize() - transfer;
                if (remainder <= 0) other.discard();
                else {
                    otherStack.mobstacker$setStackSize(remainder);
                    updateDisplayName(other);
                }
                updateDisplayName(anchor);
                if (anchorStack.mobstacker$getStackSize() >= MAX_MOB_STACK) break;
            }
        }
    }

    private static boolean isEligible(MobEntity mob) {
        if (!mob.isAlive() || mob.isRemoved() || mob.hasVehicle() || mob.hasPassengers()) return false;
        if (mob.getType() == net.minecraft.entity.EntityType.ENDER_DRAGON ||
                mob.getType() == net.minecraft.entity.EntityType.WITHER ||
                mob.getType() == net.minecraft.entity.EntityType.WARDEN ||
                mob.getType() == net.minecraft.entity.EntityType.VILLAGER ||
                mob.getType() == net.minecraft.entity.EntityType.WOLF ||
                mob.getType() == net.minecraft.entity.EntityType.CAT) return false;
        if (mob.hasCustomName()) {
            String name = mob.getCustomName().getString();
            if (!name.startsWith("[MobStacker] ")) return false;
        }
        return true;
    }

    private static void updateDisplayName(MobEntity mob) {
        int count = ((StackableMob) mob).mobstacker$getStackSize();
        if (count <= 1) {
            mob.setCustomName(null);
            mob.setCustomNameVisible(false);
        } else {
            mob.setCustomName(Text.literal("[MobStacker] " + mob.getType().getName().getString() + " x " + count));
            mob.setCustomNameVisible(true);
        }
    }
}
