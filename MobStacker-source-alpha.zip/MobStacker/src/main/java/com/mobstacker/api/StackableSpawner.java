package com.mobstacker.api;

public interface StackableSpawner {
    long mobstacker$getStackSize();
    void mobstacker$setStackSize(long size);
}
