package com.mobstacker.api;

public interface StackableMob {
    int mobstacker$getStackSize();
    void mobstacker$setStackSize(int size);
}
