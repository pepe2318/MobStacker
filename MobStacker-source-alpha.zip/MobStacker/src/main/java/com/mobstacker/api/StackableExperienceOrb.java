package com.mobstacker.api;

public interface StackableExperienceOrb {
    void mobstacker$setExperienceAmount(int amount);
}
