package com.mobstacker.mixin;

import com.mobstacker.api.StackableMob;
import net.minecraft.entity.mob.MobEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(MobEntity.class)
public abstract class MobEntityMixin implements StackableMob {
    @Unique private int mobstacker$stackSize = 1;

    @Override
    public int mobstacker$getStackSize() {
        return mobstacker$stackSize;
    }

    @Override
    public void mobstacker$setStackSize(int size) {
        mobstacker$stackSize = Math.max(1, Math.min(10_000, size));
    }
}
