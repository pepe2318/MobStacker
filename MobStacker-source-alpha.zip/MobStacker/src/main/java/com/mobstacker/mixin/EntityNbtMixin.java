package com.mobstacker.mixin;

import com.mobstacker.api.StackableMob;
import net.minecraft.entity.Entity;
import net.minecraft.storage.ReadView;
import net.minecraft.storage.WriteView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityNbtMixin {
    @Inject(method = "writeData", at = @At("TAIL"))
    private void mobstacker$saveStack(WriteView view, CallbackInfo ci) {
        if ((Object) this instanceof StackableMob stack && stack.mobstacker$getStackSize() > 1) {
            view.putInt("MobStackerCount", stack.mobstacker$getStackSize());
        }
    }

    @Inject(method = "readData", at = @At("TAIL"))
    private void mobstacker$loadStack(ReadView view, CallbackInfo ci) {
        if ((Object) this instanceof StackableMob stack) {
            stack.mobstacker$setStackSize(view.getInt("MobStackerCount", 1));
        }
    }
}
