package com.mobstacker.mixin;

import com.mobstacker.api.StackableMob;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NbtCompound;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityNbtMixin {
    @Inject(method = "writeNbt", at = @At("TAIL"))
    private void mobstacker$saveStack(NbtCompound nbt, CallbackInfoReturnable<NbtCompound> cir) {
        if ((Object) this instanceof StackableMob stack && stack.mobstacker$getStackSize() > 1) {
            nbt.putInt("MobStackerCount", stack.mobstacker$getStackSize());
        }
    }

    @Inject(method = "readNbt", at = @At("TAIL"))
    private void mobstacker$loadStack(NbtCompound nbt, CallbackInfo ci) {
        if ((Object) this instanceof StackableMob stack && nbt.contains("MobStackerCount")) {
            stack.mobstacker$setStackSize(nbt.getInt("MobStackerCount"));
        }
    }
}
