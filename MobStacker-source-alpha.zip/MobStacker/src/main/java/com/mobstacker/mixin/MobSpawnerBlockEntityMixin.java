package com.mobstacker.mixin;

import com.mobstacker.api.StackableSpawner;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.storage.ReadView;
import net.minecraft.storage.WriteView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MobSpawnerBlockEntity.class)
public abstract class MobSpawnerBlockEntityMixin implements StackableSpawner {
    @Unique private long mobstacker$stackSize = 1L;

    @Override public long mobstacker$getStackSize() { return mobstacker$stackSize; }
    @Override public void mobstacker$setStackSize(long size) { mobstacker$stackSize = Math.max(1L, size); }

    @Inject(method = "writeData", at = @At("TAIL"))
    private void mobstacker$writeSpawnerStack(WriteView view, CallbackInfo ci) {
        if (mobstacker$stackSize > 1L) view.putLong("MobStackerCount", mobstacker$stackSize);
    }

    @Inject(method = "readData", at = @At("TAIL"))
    private void mobstacker$readSpawnerStack(ReadView view, CallbackInfo ci) {
        mobstacker$stackSize = Math.max(1L, view.getLong("MobStackerCount", 1L));
    }
}
