package com.mobstacker.mixin;

import com.mobstacker.api.StackableSpawner;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MobSpawnerBlockEntity.class)
public abstract class MobSpawnerBlockEntityMixin implements StackableSpawner {
    @Unique private long mobstacker$stackSize = 1L;

    @Override public long mobstacker$getStackSize() { return mobstacker$stackSize; }
    @Override public void mobstacker$setStackSize(long size) { mobstacker$stackSize = Math.max(1L, size); }

    @Inject(method = "writeNbt", at = @At("TAIL"))
    private void mobstacker$writeSpawnerStack(NbtCompound nbt, RegistryWrapper.WrapperLookup registries, CallbackInfo ci) {
        if (mobstacker$stackSize > 1L) nbt.putLong("MobStackerCount", mobstacker$stackSize);
    }

    @Inject(method = "readNbt", at = @At("TAIL"))
    private void mobstacker$readSpawnerStack(NbtCompound nbt, RegistryWrapper.WrapperLookup registries, CallbackInfo ci) {
        if (nbt.contains("MobStackerCount")) mobstacker$stackSize = Math.max(1L, nbt.getLong("MobStackerCount"));
    }
}
