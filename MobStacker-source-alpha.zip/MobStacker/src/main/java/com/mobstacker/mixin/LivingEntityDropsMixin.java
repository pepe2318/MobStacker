package com.mobstacker.mixin;

import com.mobstacker.api.StackableMob;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public abstract class LivingEntityDropsMixin {
    @Shadow protected abstract void dropLoot(ServerWorld world, DamageSource source, boolean causedByPlayer);
    @Shadow protected abstract void dropExperience(ServerWorld world, Entity attacker);

    @Unique private static final ThreadLocal<Boolean> MOBSTACKER$IN_LOOT = ThreadLocal.withInitial(() -> false);
    @Unique private static final ThreadLocal<Boolean> MOBSTACKER$IN_XP = ThreadLocal.withInitial(() -> false);

    @Inject(method = "dropLoot(Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/entity/damage/DamageSource;Z)V", at = @At("HEAD"), cancellable = true)
    private void mobstacker$multiplyLoot(ServerWorld world, DamageSource source, boolean causedByPlayer, CallbackInfo ci) {
        if (MOBSTACKER$IN_LOOT.get() || !((Object) this instanceof StackableMob stack)) return;
        int count = stack.mobstacker$getStackSize();
        if (count <= 1) return;

        stack.mobstacker$setStackSize(1);
        MOBSTACKER$IN_LOOT.set(true);
        try {
            for (int i = 0; i < count; i++) dropLoot(world, source, causedByPlayer);
        } finally {
            MOBSTACKER$IN_LOOT.remove();
            stack.mobstacker$setStackSize(count);
        }
        ci.cancel();
    }

    @Inject(method = "dropExperience(Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/entity/Entity;)V", at = @At("HEAD"), cancellable = true)
    private void mobstacker$multiplyExperience(ServerWorld world, Entity attacker, CallbackInfo ci) {
        if (MOBSTACKER$IN_XP.get() || !((Object) this instanceof StackableMob stack)) return;
        int count = stack.mobstacker$getStackSize();
        if (count <= 1) return;

        stack.mobstacker$setStackSize(1);
        MOBSTACKER$IN_XP.set(true);
        try {
            for (int i = 0; i < count; i++) dropExperience(world, attacker);
        } finally {
            MOBSTACKER$IN_XP.remove();
            stack.mobstacker$setStackSize(count);
        }
        ci.cancel();
    }
}
