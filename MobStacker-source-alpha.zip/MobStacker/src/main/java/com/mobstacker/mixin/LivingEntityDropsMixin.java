package com.mobstacker.mixin;

import com.mobstacker.api.StackableExperienceOrb;
import com.mobstacker.api.StackableMob;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Mixin(LivingEntity.class)
public abstract class LivingEntityDropsMixin {
    @Shadow protected abstract void dropLoot(ServerWorld world, DamageSource source, boolean causedByPlayer);
    @Shadow protected abstract void dropExperience(ServerWorld world, Entity attacker);

    @Unique private static final ThreadLocal<Boolean> MOBSTACKER$IN_LOOT = ThreadLocal.withInitial(() -> false);
    @Unique private static final ThreadLocal<Boolean> MOBSTACKER$IN_XP = ThreadLocal.withInitial(() -> false);

    @Inject(method = "dropLoot(Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/entity/damage/DamageSource;Z)V", at = @At("HEAD"), cancellable = true)
    private void mobstacker$multiplyLoot(ServerWorld world, DamageSource source, boolean causedByPlayer, CallbackInfo ci) {
        if (MOBSTACKER$IN_LOOT.get() || !((Object) this instanceof StackableMob stack)) return;
        int count = stack.mobstacker$getStackSize();
        if (count <= 1) return;

        LivingEntity self = (LivingEntity) (Object) this;
        Box captureArea = self.getBoundingBox().expand(4.0);
        Set<UUID> existing = new HashSet<>();
        for (ItemEntity item : world.getEntitiesByClass(ItemEntity.class, captureArea, entity -> true)) {
            existing.add(item.getUuid());
        }

        stack.mobstacker$setStackSize(1);
        MOBSTACKER$IN_LOOT.set(true);
        try {
            for (int i = 0; i < count; i++) dropLoot(world, source, causedByPlayer);
        } finally {
            MOBSTACKER$IN_LOOT.remove();
            stack.mobstacker$setStackSize(count);
        }

        List<ItemEntity> newDrops = world.getEntitiesByClass(ItemEntity.class, captureArea,
                item -> !existing.contains(item.getUuid()));
        mobstacker$mergeItemDrops(newDrops);
        ci.cancel();
    }

    @Inject(method = "dropExperience(Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/entity/Entity;)V", at = @At("HEAD"), cancellable = true)
    private void mobstacker$multiplyExperience(ServerWorld world, Entity attacker, CallbackInfo ci) {
        if (MOBSTACKER$IN_XP.get() || !((Object) this instanceof StackableMob stack)) return;
        int count = stack.mobstacker$getStackSize();
        if (count <= 1) return;

        LivingEntity self = (LivingEntity) (Object) this;
        Box captureArea = self.getBoundingBox().expand(4.0);
        Set<UUID> existing = new HashSet<>();
        for (ExperienceOrbEntity orb : world.getEntitiesByClass(ExperienceOrbEntity.class, captureArea, entity -> true)) {
            existing.add(orb.getUuid());
        }

        stack.mobstacker$setStackSize(1);
        MOBSTACKER$IN_XP.set(true);
        try {
            for (int i = 0; i < count; i++) dropExperience(world, attacker);
        } finally {
            MOBSTACKER$IN_XP.remove();
            stack.mobstacker$setStackSize(count);
        }

        List<ExperienceOrbEntity> newOrbs = world.getEntitiesByClass(ExperienceOrbEntity.class, captureArea,
                orb -> !existing.contains(orb.getUuid()));
        mobstacker$mergeExperienceOrbs(newOrbs);
        ci.cancel();
    }

    @Unique
    private static void mobstacker$mergeItemDrops(List<ItemEntity> drops) {
        List<ItemEntity> grouped = new ArrayList<>();
        for (ItemEntity drop : drops) {
            if (!drop.isAlive() || drop.getStack().isEmpty()) continue;
            ItemStack source = drop.getStack();
            boolean mergedCompletely = false;

            for (ItemEntity target : grouped) {
                ItemStack targetStack = target.getStack();
                if (!target.isAlive() || !ItemStack.areItemsAndComponentsEqual(targetStack, source)) continue;
                int room = targetStack.getMaxCount() - targetStack.getCount();
                if (room <= 0) continue;
                int moved = Math.min(room, source.getCount());
                targetStack.increment(moved);
                source.decrement(moved);
                target.setStack(targetStack);
                if (source.isEmpty()) {
                    drop.discard();
                    mergedCompletely = true;
                    break;
                }
            }

            if (!mergedCompletely) grouped.add(drop);
        }
    }

    @Unique
    private static void mobstacker$mergeExperienceOrbs(List<ExperienceOrbEntity> orbs) {
        if (orbs.size() <= 1) return;
        long total = 0L;
        for (ExperienceOrbEntity orb : orbs) {
            if (!orb.isRemoved()) total += orb.getExperienceAmount();
        }
        if (total <= 0L) return;

        // Keep only as many orbs as needed to represent the full XP total.
        // This also avoids integer overflow for unusual modded mobs.
        long remaining = total;
        for (ExperienceOrbEntity orb : orbs) {
            if (orb.isRemoved()) continue;
            if (remaining <= 0L) {
                orb.discard();
                continue;
            }
            int value = (int) Math.min(Integer.MAX_VALUE, remaining);
            ((StackableExperienceOrb) orb).mobstacker$setExperienceAmount(value);
            remaining -= value;
        }
    }
}
