package com.mobstacker.mixin;

import com.mobstacker.api.StackableExperienceOrb;
import net.minecraft.entity.ExperienceOrbEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(ExperienceOrbEntity.class)
public abstract class ExperienceOrbEntityMixin implements StackableExperienceOrb {
    @Shadow private int amount;

    @Override
    public void mobstacker$setExperienceAmount(int amount) {
        this.amount = Math.max(0, amount);
    }
}
