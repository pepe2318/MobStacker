package com.mobstacker.mixin;

import com.mobstacker.api.StackableExperienceOrb;
import net.minecraft.entity.ExperienceOrbEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(ExperienceOrbEntity.class)
public abstract class ExperienceOrbEntityMixin implements StackableExperienceOrb {
    @Invoker("setValue")
    protected abstract void mobstacker$invokeSetValue(int value);

    @Override
    public void mobstacker$setExperienceAmount(int amount) {
        mobstacker$invokeSetValue(Math.max(0, amount));
    }
}
