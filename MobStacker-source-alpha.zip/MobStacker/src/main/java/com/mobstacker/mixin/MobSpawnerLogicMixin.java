package com.mobstacker.mixin;

import com.mobstacker.api.StackableSpawner;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.spawner.MobSpawnerLogic;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MobSpawnerLogic.class)
public abstract class MobSpawnerLogicMixin {
    @Shadow private int spawnCount;
    @Shadow private int maxNearbyEntities;

    @Unique private int mobstacker$originalSpawnCount;
    @Unique private int mobstacker$originalMaxNearbyEntities;
    @Unique private boolean mobstacker$changedSpawnerLimits;

    @Inject(method = "serverTick", at = @At("HEAD"))
    private void mobstacker$scaleSpawnerOutput(ServerWorld world, BlockPos pos, CallbackInfo ci) {
        BlockEntity blockEntity = world.getBlockEntity(pos);
        if (!(blockEntity instanceof MobSpawnerBlockEntity spawner) || !(spawner instanceof StackableSpawner stacked)) return;

        long amount = Math.max(1L, stacked.mobstacker$getStackSize());
        if (amount <= 1L) return;

        mobstacker$originalSpawnCount = spawnCount;
        mobstacker$originalMaxNearbyEntities = maxNearbyEntities;

        // Vanilla's nearby-entity cap otherwise stops a stacked spawner after
        // reaching the same limit as a single spawner.
        spawnCount = (int) Math.min(10_000L, Math.max(1L, (long) spawnCount * amount));
        maxNearbyEntities = (int) Math.min(100_000L, Math.max(1L, (long) maxNearbyEntities * amount));
        mobstacker$changedSpawnerLimits = true;
    }

    @Inject(method = "serverTick", at = @At("RETURN"))
    private void mobstacker$restoreSpawnerOutput(ServerWorld world, BlockPos pos, CallbackInfo ci) {
        if (!mobstacker$changedSpawnerLimits) return;
        spawnCount = mobstacker$originalSpawnCount;
        maxNearbyEntities = mobstacker$originalMaxNearbyEntities;
        mobstacker$changedSpawnerLimits = false;
    }
}
