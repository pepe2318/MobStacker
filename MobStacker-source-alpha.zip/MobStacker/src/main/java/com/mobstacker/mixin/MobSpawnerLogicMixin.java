package com.mobstacker.mixin;

import com.mobstacker.api.StackableSpawner;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.spawner.MobSpawnerLogic;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MobSpawnerLogic.class)
public abstract class MobSpawnerLogicMixin {
    @Shadow private int spawnCount;
    @Unique private int mobstacker$originalSpawnCount;
    @Unique private boolean mobstacker$changedSpawnCount;

    @Inject(method = "serverTick", at = @At("HEAD"))
    private void mobstacker$scaleSpawnerOutput(ServerWorld world, BlockPos pos, CallbackInfo ci) {
        BlockEntity blockEntity = world.getBlockEntity(pos);
        if (blockEntity instanceof MobSpawnerBlockEntity spawner && spawner instanceof StackableSpawner stacked) {
            long amount = stacked.mobstacker$getStackSize();
            if (amount > 1L) {
                mobstacker$originalSpawnCount = spawnCount;
                long scaled = (long) spawnCount * amount;
                spawnCount = (int) Math.min(1_000_000L, Math.max(1L, scaled));
                mobstacker$changedSpawnCount = true;
            }
        }
    }

    @Inject(method = "serverTick", at = @At("RETURN"))
    private void mobstacker$restoreSpawnerOutput(ServerWorld world, BlockPos pos, CallbackInfo ci) {
        if (mobstacker$changedSpawnCount) {
            spawnCount = mobstacker$originalSpawnCount;
            mobstacker$changedSpawnCount = false;
        }
    }
}
