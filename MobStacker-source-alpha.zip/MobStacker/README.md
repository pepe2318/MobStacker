# MobStacker — alpha source project

Target: Minecraft Java 1.21.10, Fabric Loader 0.17.2, Java 21.

## Current alpha behavior (0.1.1-alpha source revision)

- Attempts to merge nearby mobs of the same `EntityType` into one active `MobEntity`.
- Does not merge villagers, wolves, or cats. Ender dragons, withers, and wardens are also excluded.
- Stores mob stack counts in entity data, with a maximum of 10,000 per stack.
- Replays vanilla loot and XP calculations for each mob in a stack, then combines matching item entities up to each item's normal maximum stack size and combines the generated XP into fewer orbs.
- Stores a `long` spawner stack count in the spawner block entity.
- Right-clicking a spawner (or the adjacent block where a spawner would be placed) with a `minecraft:spawner` item adds one to the target spawner's stored count.
- Scales both `spawnCount` and the vanilla nearby-entity limit according to the spawner stack size. A default spawner with stack size 2 targets up to 8 spawn attempts per cycle; stack size 10 targets up to 40. Actual successful spawns still depend on vanilla spawn conditions and available space.

## Important limitations — test on a disposable world first

This is an **alpha source revision and has not yet been compiled or integration-tested** against a live Minecraft 1.21.10 server. The loot and XP routines still execute once per mob before the resulting item entities and XP orbs are merged, so very large stacks can still cause a temporary workload spike during death processing. Item merging preserves item components and respects each item's normal maximum stack size; XP merging preserves the total XP value.

The spawner interaction does not yet verify that the spawner item being added has exactly the same spawn-entity configuration as the target spawner. Automatic adjacent spawner merging on placement is not implemented. Back up the world and test on a disposable server before using this alpha on a valuable or public world.

## Build

Requires JDK 21 and Gradle 8.12+ (the Loom version in this project is 1.11.8).

From this folder run:

```bash
gradle build
```

The remapped mod jar, if compilation succeeds, will be in `build/libs/` and will not be the `-sources.jar` file.

## Dependency

Fabric API is currently declared as a required dependency. The server must use Fabric for Minecraft 1.21.10 and the same Fabric API version or a compatible newer 1.21.10 release.

## Build it with GitHub Actions (without installing Gradle on your phone)

The repository includes `.github/workflows/build.yml`. After placing this project in a GitHub repository, open **Actions**, choose **Build MobStacker**, and run the workflow. If the build succeeds, download the `MobStacker-alpha-jars` artifact from that run. This is still only a compilation step; it does not replace testing on a disposable 1.21.10 server.
